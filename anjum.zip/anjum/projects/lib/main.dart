// main.dart
// Fixed version — compatible with latest Flutter SDK (CardThemeData fix)

import 'package:flutter/material.dart';

final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);

void main() {
  runApp(MyProfileApp());
}

class MyProfileApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, ThemeMode currentMode, __) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'My Profile App',
          theme: ThemeData(
            brightness: Brightness.light,
            primarySwatch: Colors.indigo,
            cardTheme: const CardThemeData(
              elevation: 4,
              margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            ),
          ),
          darkTheme: ThemeData(
            brightness: Brightness.dark,
            primarySwatch: Colors.indigo,
            cardTheme: const CardThemeData(
              elevation: 4,
              margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            ),
          ),
          themeMode: currentMode,
          initialRoute: '/',
          routes: {
            '/': (_) => WelcomeScreen(),
            '/profile': (_) => ProfileScreen(),
            '/about': (_) => AboutScreen(),
          },
        );
      },
    );
  }
}

// -------------------- Welcome Screen --------------------
class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.indigo.shade400, Colors.purple.shade400],
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(flex: 2),
              Icon(Icons.person, size: size.width * 0.22, color: Colors.white70),
              const SizedBox(height: 16),
              const Text(
                'Welcome back! Farman Ali',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.white),
              ),
              const SizedBox(height: 12),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 28.0),
                child: Text(
                  'A simple Flutter UI showcasing profile, contact details, and an about page.\nTap below to view the profile.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white70),
                ),
              ),
              const Spacer(flex: 3),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => Navigator.pushNamed(context, '/profile'),
                    style: ElevatedButton.styleFrom(shape: const StadiumBorder()),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 14.0),
                      child: Text('View Profile', style: TextStyle(fontSize: 16)),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// -------------------- Dummy User Model --------------------
class UserProfile {
  final String name;
  final String profession;
  final String bio;
  final String email;
  final String phone;
  final String location;
  final String imageAsset;

  UserProfile({
    required this.name,
    required this.profession,
    required this.bio,
    required this.email,
    required this.phone,
    required this.location,
    required this.imageAsset,
  });
}

final UserProfile me = UserProfile(
  name: 'Anjum Ali',
  profession: 'Flutter Developer',
  bio: 'Passionate about building beautiful and responsive mobile apps using Flutter. Loves clean UI and delightful UX',
  email: 'anjumaligocho786@gmail.com',
  phone: '+923 346 222 5440',
  location: 'Gilgit, Pakistan',
  imageAsset: 'assets/images/profile.jpg',
);

// -------------------- Profile Screen --------------------
class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          ValueListenableBuilder<ThemeMode>(
            valueListenable: themeNotifier,
            builder: (_, mode, __) {
              return IconButton(
                tooltip: 'Toggle Dark/Light',
                icon: Icon(mode == ThemeMode.light ? Icons.dark_mode : Icons.light_mode),
                onPressed: () {
                  themeNotifier.value = mode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
                },
              );
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.info_outline),
        onPressed: () => Navigator.pushNamed(context, '/about'),
        tooltip: 'About Me',
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 20),
            CircleAvatar(
              radius: width * 0.18,
              backgroundImage: AssetImage(me.imageAsset),
            ),
            const SizedBox(height: 12),
            Text(me.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(me.profession, style: const TextStyle(fontSize: 14, color: Colors.grey)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22.0, vertical: 12),
              child: Text(me.bio, textAlign: TextAlign.center),
            ),
            ContactCard(user: me),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.linked_camera),
                    tooltip: 'LinkedIn',
                    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Open LinkedIn'))),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.code),
                    tooltip: 'GitHub',
                    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Open GitHub'))),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.chat),
                    tooltip: 'Twitter',
                    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Open Twitter'))),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class ContactCard extends StatelessWidget {
  final UserProfile user;
  const ContactCard({required this.user});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Contact', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.email),
              title: Text(user.email),
              subtitle: const Text('Email'),
            ),
            ListTile(
              leading: const Icon(Icons.phone),
              title: Text(user.phone),
              subtitle: const Text('Phone'),
            ),
            ListTile(
              leading: const Icon(Icons.location_on),
              title: Text(user.location),
              subtitle: const Text('Location'),
            ),
          ],
        ),
      ),
    );
  }
}

// -------------------- About Screen --------------------
class AboutScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final skills = ['Flutter', 'Dart', 'Graphic Design', 'Git', 'Digital Marketing', 'Website Design'];
    final education = [
      'BS Computer Science — Karakoram International University (2023)',
      'Certificate: Flutter Development'
    ];
    final hobbies = ['Reading', 'Coding', 'Traveling', 'Photography'];

    return Scaffold(
      appBar: AppBar(
        title: const Text('About Me'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Education', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  ...education.map((e) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6.0),
                    child: Text('• $e'),
                  )),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Skills', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: skills.map((s) => Chip(label: Text(s))).toList(),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Hobbies', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  ...hobbies.map((h) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6.0),
                    child: Text('• $h'),
                  )),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back),
            label: const Text('Back to Profile'),
          ),
        ],
      ),
    );
  }
}